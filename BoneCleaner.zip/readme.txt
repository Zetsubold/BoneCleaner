BoneCleaner

A tool that deletes all bonemod files containing default data (that is - the file
doesn't do anything to modify the assosiated character model).

Works only on the directory the program was launched from, so copy the program to
where the character cards are.
